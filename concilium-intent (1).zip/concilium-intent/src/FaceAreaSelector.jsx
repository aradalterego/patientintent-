import React, { useEffect, useRef, useState, useMemo, useCallback } from "react";
import { FaceLandmarker, FilesetResolver } from "@mediapipe/tasks-vision";

/* ============================================================
   Concilium — Patient Intent capture (Agent 6 front-end)
   Runs on a frontal_neutral photo. MediaPipe Face Landmarker
   returns 468 points; each perceptual region is an ORDERED
   polygon of canonical indices (calibrated against a real face).
   region -> zones is translated in the backend. The perceived-
   state layer (zone -> state) is isolated from the diagnostic
   pipeline and only joins at JOIN Final.

   Calibration: all index lists live in POLY / BAND below. If a
   polygon sits slightly off on a given face, toggle "Calibration
   points" to see the 468 numbered landmarks and swap an index.
   ============================================================ */

const MODEL_URL =
  "https://storage.googleapis.com/mediapipe-models/face_landmarker/face_landmarker/float16/1/face_landmarker.task";
const WASM_URL = "https://cdn.jsdelivr.net/npm/@mediapipe/tasks-vision@0.10.14/wasm";

/* ordered polygons (perimeter order), verified on a frontal face */
const POLY = {
  forehead: [103, 67, 109, 10, 338, 297, 332, 334, 296, 9, 107, 66, 105],
  glabella: [9, 107, 55, 8, 285, 336],
  nose: [168, 122, 48, 64, 98, 2, 326, 294, 278, 351],
  upper_lip: [97, 167, 165, 40, 0, 270, 391, 393, 326, 2],
  lips: [61, 146, 91, 181, 84, 17, 314, 405, 321, 375, 291, 409, 270, 269, 267, 0, 37, 39, 40, 185],
  chin: [182, 83, 18, 313, 406, 377, 152, 148, 176],
  brow_R: [70, 63, 105, 66, 107, 55, 65, 52, 53, 46],
  brow_L: [336, 296, 334, 293, 300, 276, 283, 282, 295, 285],
  upperlid_R: [33, 246, 161, 160, 159, 158, 157, 173, 133, 56, 28, 27, 29, 30, 247],
  upperlid_L: [263, 466, 388, 387, 386, 385, 384, 398, 362, 286, 258, 257, 259, 260, 467],
  undereye_R: [33, 7, 163, 144, 145, 153, 154, 155, 133, 244, 233, 232, 231, 230, 229, 228, 31, 226],
  undereye_L: [263, 249, 390, 373, 374, 380, 381, 382, 362, 464, 453, 452, 451, 450, 449, 448, 261, 446],
  cheek_R: [117, 118, 119, 120, 205, 187, 147, 123],
  cheek_L: [346, 347, 348, 349, 425, 411, 376, 352],
  nasolabial_R: [129, 165, 92, 57, 206, 209],
  nasolabial_L: [358, 391, 322, 287, 426, 429],
  mouth_R: [61, 91, 181, 84, 83, 182, 106, 43, 57],
  mouth_L: [291, 321, 405, 314, 313, 406, 335, 273, 287],
};
/* jaw rendered as a thin band (mandible line + inset toward centroid) */
const BAND = {
  jaw_R: [58, 172, 136, 150, 149, 176, 148, 152],
  jaw_L: [152, 377, 400, 378, 379, 365, 397, 288],
};

/* zone -> perceived states (reverse of the approved state→zone table) */
const ZONE_STATES = {
  forehead: ["stressed"],
  glabella: ["angry", "stressed"],
  brow_complex: ["tired", "sad", "angry", "stressed"],
  upper_eyelid: ["tired"],
  tear_trough: ["tired", "sad", "aged", "gaunt"],
  lower_eyelid: ["tired", "gaunt", "dull"],
  temples: ["gaunt"],
  malar_zygomatic: ["tired", "sad", "gaunt", "dull"],
  buccal_submalar: ["gaunt", "heavy"],
  nasolabial: ["aged"],
  lips: ["aged"],
  oral_commissures: ["sad", "angry", "aged", "heavy"],
  jawline: ["aged", "heavy"],
  mandibular_border: ["aged", "heavy"],
  nose: [],
  lateral_canthal: [],
  chin: [],
};
const STATE_LABELS = {
  tired: "Tired",
  sad: "Sad",
  angry: "Angry / stern",
  aged: "Older",
  heavy: "Heavy / sagging",
  gaunt: "Gaunt / hollow",
  stressed: "Tense / worried",
  dull: "Dull skin",
};

/* perceptual regions shown to the patient */
const REGIONS = [
  { key: "forehead", label: "Forehead", bilateral: false, zones: ["forehead"], poly: ["forehead"] },
  { key: "glabella", label: "Between brows", bilateral: false, zones: ["glabella"], poly: ["glabella"] },
  { key: "brows", label: "Brows", bilateral: true, zones: ["brow_complex"], poly: ["brow_R", "brow_L"] },
  { key: "upper_lids", label: "Upper eyelids", bilateral: true, zones: ["upper_eyelid"], poly: ["upperlid_R", "upperlid_L"] },
  { key: "under_eye", label: "Under-eye", bilateral: true, zones: ["tear_trough", "lower_eyelid"], poly: ["undereye_R", "undereye_L"] },
  { key: "cheeks", label: "Cheeks", bilateral: true, zones: ["malar_zygomatic", "buccal_submalar"], poly: ["cheek_R", "cheek_L"] },
  { key: "nose", label: "Nose", bilateral: false, zones: ["nose"], poly: ["nose"] },
  { key: "nasolabial", label: "Nasolabial folds", bilateral: true, zones: ["nasolabial"], poly: ["nasolabial_R", "nasolabial_L"] },
  { key: "upper_lip", label: "Upper lip", bilateral: false, zones: ["lips"], poly: ["upper_lip"] },
  { key: "lips", label: "Lips", bilateral: false, zones: ["lips"], poly: ["lips"] },
  { key: "mouth_corners", label: "Mouth corners", bilateral: true, zones: ["oral_commissures"], poly: ["mouth_R", "mouth_L"] },
  { key: "jawline", label: "Jawline", bilateral: true, zones: ["jawline", "mandibular_border"], band: ["jaw_R", "jaw_L"] },
  { key: "chin", label: "Chin", bilateral: false, zones: ["chin"], poly: ["chin"] },
];

/* edge regions, hard to click on a frontal photo — shown as external chips with a leader */
const EXTERNAL = [
  { key: "temples", label: "Temples", bilateral: true, zones: ["temples"], anchor: { right: 54, left: 284 } },
  { key: "crows_feet", label: "Crow's feet", bilateral: true, zones: ["lateral_canthal"], anchor: { right: 130, left: 359 } },
];

const SIDE_LABELS = { both: "Both sides", right: "Right", left: "Left" };
const ALL = [...REGIONS, ...EXTERNAL];
const regionByKey = Object.fromEntries(ALL.map((r) => [r.key, r]));

/* ---------- geometry ---------- */
const toPath = (pts) => pts.map((p) => `${p.x.toFixed(1)},${p.y.toFixed(1)}`).join(" ");
function polyPts(indices, lm, w, h) {
  return indices.map((i) => lm[i]).filter(Boolean).map((p) => ({ x: p.x * w, y: p.y * h }));
}
function bandPts(indices, lm, w, h, cx, cy, inset = 0.14) {
  const line = indices.map((i) => lm[i]).filter(Boolean).map((p) => ({ x: p.x * w, y: p.y * h }));
  const inner = [...line].reverse().map((p) => ({ x: p.x + (cx - p.x) * inset, y: p.y + (cy - p.y) * inset }));
  return line.concat(inner);
}
function centroid(pts) {
  const cx = pts.reduce((s, p) => s + p.x, 0) / pts.length;
  const cy = pts.reduce((s, p) => s + p.y, 0) / pts.length;
  return { cx, cy };
}

/* ---------- component ---------- */
export default function FaceAreaSelector() {
  const [landmarker, setLandmarker] = useState(null);
  const [loadingModel, setLoadingModel] = useState(true);
  const [modelError, setModelError] = useState(null);

  const [imgSrc, setImgSrc] = useState(null);
  const [imgDims, setImgDims] = useState({ w: 0, h: 0 });
  const [landmarks, setLandmarks] = useState(null);
  const [detecting, setDetecting] = useState(false);
  const [detectError, setDetectError] = useState(null);

  const [selections, setSelections] = useState({});
  const [activeKey, setActiveKey] = useState(null);
  const [activeSide, setActiveSide] = useState("both");
  const [debug, setDebug] = useState(false);

  const imgRef = useRef(null);
  const fileRef = useRef(null);

  useEffect(() => {
    let cancelled = false;
    (async () => {
      try {
        const fileset = await FilesetResolver.forVisionTasks(WASM_URL);
        const lm = await FaceLandmarker.createFromOptions(fileset, {
          baseOptions: { modelAssetPath: MODEL_URL, delegate: "GPU" },
          runningMode: "IMAGE",
          numFaces: 1,
        });
        if (!cancelled) { setLandmarker(lm); setLoadingModel(false); }
      } catch (e) {
        if (!cancelled) { setModelError(e?.message || "model load failed"); setLoadingModel(false); }
      }
    })();
    return () => { cancelled = true; };
  }, []);

  const onFile = (e) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setSelections({}); setActiveKey(null); setLandmarks(null); setDetectError(null);
    setImgSrc(URL.createObjectURL(file));
  };

  const onImgLoad = useCallback(() => {
    const el = imgRef.current;
    if (!el || !landmarker) return;
    setImgDims({ w: el.naturalWidth, h: el.naturalHeight });
    setDetecting(true); setDetectError(null);
    try {
      const res = landmarker.detect(el);
      if (res?.faceLandmarks?.length) setLandmarks(res.faceLandmarks[0]);
      else setDetectError("No face detected. Use a clear, well-lit, front-facing photo.");
    } catch (e) {
      setDetectError("Detection failed: " + (e?.message || ""));
    } finally { setDetecting(false); }
  }, [landmarker]);

  const faceCenter = useMemo(() => {
    if (!landmarks) return { cx: 0, cy: 0 };
    const { w, h } = imgDims;
    const cx = landmarks.reduce((s, p) => s + p.x, 0) / landmarks.length * w;
    const cy = landmarks.reduce((s, p) => s + p.y, 0) / landmarks.length * h;
    return { cx, cy };
  }, [landmarks, imgDims]);

  const polygons = useMemo(() => {
    if (!landmarks) return [];
    const { w, h } = imgDims;
    const out = [];
    for (const r of REGIONS) {
      const keys = r.poly || r.band;
      const isBand = !!r.band;
      if (r.bilateral) {
        keys.forEach((k, i) => {
          const pts = isBand
            ? bandPts(BAND[k], landmarks, w, h, faceCenter.cx, faceCenter.cy)
            : polyPts(POLY[k], landmarks, w, h);
          if (pts.length >= 3) out.push({ region: r.key, side: i === 0 ? "right" : "left", pts });
        });
      } else {
        const pts = polyPts(POLY[keys[0]], landmarks, w, h);
        if (pts.length >= 3) out.push({ region: r.key, side: "both", pts });
      }
    }
    return out;
  }, [landmarks, imgDims, faceCenter]);

  const externals = useMemo(() => {
    if (!landmarks) return [];
    const { w, h } = imgDims;
    const margin = w * 0.04;
    const out = [];
    for (const r of EXTERNAL) {
      for (const side of ["right", "left"]) {
        const a = landmarks[r.anchor[side]];
        if (!a) continue;
        const ap = { x: a.x * w, y: a.y * h };
        const onLeft = side === "right"; // patient right = image left = screen left
        const chip = { x: onLeft ? margin : w - margin, y: ap.y };
        out.push({ region: r.key, side, ap, chip, onLeft });
      }
    }
    return out;
  }, [landmarks, imgDims]);

  const statesForRegion = useCallback((regionKey) => {
    const r = regionByKey[regionKey];
    if (!r) return [];
    const set = new Set();
    r.zones.forEach((z) => (ZONE_STATES[z] || []).forEach((s) => set.add(s)));
    return [...set];
  }, []);

  const blankSide = () => ({ rating: 0, states: [], note: "" });
  function ensureEntry(prev, regionKey) {
    if (prev[regionKey]) return prev[regionKey];
    const r = regionByKey[regionKey];
    return { split: false, both: blankSide(), left: blankSide(), right: blankSide(), bilateral: r.bilateral };
  }

  const selectRegion = (regionKey, side) => {
    setSelections((prev) => ({ ...prev, [regionKey]: { ...ensureEntry(prev, regionKey) } }));
    setActiveKey(regionKey);
    const r = regionByKey[regionKey];
    setActiveSide(r.bilateral && selections[regionKey]?.split ? side : "both");
  };
  const removeRegion = (regionKey) => {
    setSelections((prev) => { const n = { ...prev }; delete n[regionKey]; return n; });
    if (activeKey === regionKey) setActiveKey(null);
  };

  const activeRegion = activeKey ? regionByKey[activeKey] : null;
  const activeEntry = activeKey ? selections[activeKey] : null;
  const sideKey = activeEntry?.split ? activeSide : "both";
  const sideData = activeEntry ? activeEntry[sideKey] : null;

  const patch = (changes) => {
    setSelections((prev) => {
      const entry = { ...ensureEntry(prev, activeKey) };
      entry[sideKey] = { ...entry[sideKey], ...changes };
      return { ...prev, [activeKey]: entry };
    });
  };
  const toggleSplit = () => {
    setSelections((prev) => {
      const entry = { ...ensureEntry(prev, activeKey) };
      if (!entry.split) { entry.split = true; entry.left = { ...entry.both }; entry.right = { ...entry.both }; }
      else { entry.split = false; }
      return { ...prev, [activeKey]: entry };
    });
    setActiveSide("right");
  };
  const toggleState = (s) => {
    const cur = sideData.states;
    patch({ states: cur.includes(s) ? cur.filter((x) => x !== s) : [...cur, s] });
  };

  const isPolySelected = (regionKey, side) => {
    const e = selections[regionKey];
    if (!e) return false;
    if (!e.bilateral || !e.split) return true;
    return e[side]?.rating > 0 || e[side]?.states.length || e[side]?.note;
  };
  const ratingOf = (regionKey, side) => {
    const e = selections[regionKey];
    if (!e) return 0;
    return e.split ? e[side]?.rating : e.both?.rating;
  };

  function clean(side) { return { rating: side.rating || null, states: side.states, note: side.note.trim() }; }
  const intent = useMemo(() => {
    const sel = [];
    for (const [key, e] of Object.entries(selections)) {
      const r = regionByKey[key];
      const base = { region_key: key, zones: r.zones };
      if (e.bilateral && e.split) sel.push({ ...base, split: true, sides: { right: clean(e.right), left: clean(e.left) } });
      else sel.push({ ...base, split: false, ...clean(e.both) });
    }
    return { schema: "patient_intent_v0.1", selections: sel };
  }, [selections]);

  const exportJson = () => {
    const blob = new Blob([JSON.stringify(intent, null, 2)], { type: "application/json" });
    const a = document.createElement("a");
    a.href = URL.createObjectURL(blob); a.download = "patient_intent.json"; a.click();
  };

  const selectedCount = Object.keys(selections).length;
  const fs = Math.max(imgDims.w, imgDims.h) || 1000;

  return (
    <div className="app">
      <header className="app-head">
        <span className="brand-tag">Concilium · Patient Intent</span>
        <h1 className="app-title">Which areas bother you most?</h1>
        <p className="app-sub">
          Tap the areas on your photo you'd like to treat. For each one you can say how much it bothers you and
          what concerns you. This is your input — it's shown to your physician alongside the system's assessment.
        </p>
      </header>

      {!imgSrc && (
        <div className="upload">
          <h2>Upload a front photo</h2>
          <p>A front-facing, well-lit photo, looking straight at the camera (frontal_neutral).</p>
          <button className="btn" disabled={loadingModel && !modelError} onClick={() => fileRef.current?.click()}>
            {loadingModel ? "Loading detector…" : "Choose photo"}
          </button>
          <input ref={fileRef} type="file" accept="image/*" hidden onChange={onFile} />
          {modelError && (
            <p className="status err" style={{ marginTop: 14 }}>
              Detector failed to load ({modelError}). Check your connection; on a host with a strict CSP, allow
              storage.googleapis.com and cdn.jsdelivr.net.
            </p>
          )}
        </div>
      )}

      {imgSrc && (
        <>
          <div className="toolbar">
            <button className="btn btn-ghost btn-sm" onClick={() => { setImgSrc(null); setLandmarks(null); setSelections({}); setActiveKey(null); }}>
              Change photo
            </button>
            <label className="dbg">
              <input type="checkbox" checked={debug} onChange={(e) => setDebug(e.target.checked)} />
              Calibration points
            </label>
          </div>

          <div className="stage-wrap">
            <div className="stage">
              <img ref={imgRef} src={imgSrc} alt="patient" onLoad={onImgLoad} crossOrigin="anonymous" />
              {landmarks && imgDims.w > 0 && (
                <svg viewBox={`0 0 ${imgDims.w} ${imgDims.h}`} preserveAspectRatio="xMidYMid meet">
                  {/* on-face polygons */}
                  {polygons.map((pg) => {
                    const sel = isPolySelected(pg.region, pg.side);
                    const { cx, cy } = centroid(pg.pts);
                    const rating = sel ? ratingOf(pg.region, pg.side) : 0;
                    return (
                      <g key={pg.region + pg.side}>
                        <polygon className={"poly" + (sel ? " selected" : "")} points={toPath(pg.pts)} onClick={() => selectRegion(pg.region, pg.side)} />
                        {sel && rating > 0 && (
                          <>
                            <circle className="poly-badge" cx={cx} cy={cy} r={fs * 0.018} />
                            <text className="poly-badge-txt" x={cx} y={cy} style={{ fontSize: fs * 0.024 }}>{rating}</text>
                          </>
                        )}
                      </g>
                    );
                  })}
                  {/* external chips for temples / crow's feet */}
                  {externals.map((ex) => {
                    const sel = isPolySelected(ex.region, ex.side);
                    const rating = sel ? ratingOf(ex.region, ex.side) : 0;
                    const label = regionByKey[ex.region].label;
                    const cw = fs * 0.14, chh = fs * 0.045;
                    const rx = ex.onLeft ? ex.chip.x : ex.chip.x - cw;
                    return (
                      <g key={ex.region + ex.side} onClick={() => selectRegion(ex.region, ex.side)} style={{ cursor: "pointer" }}>
                        <line className="lead-line" x1={ex.ap.x} y1={ex.ap.y} x2={ex.onLeft ? rx + cw : rx} y2={ex.chip.y} />
                        <circle className="lead-dot" cx={ex.ap.x} cy={ex.ap.y} r={fs * 0.006} />
                        <rect className={"chip-rect" + (sel ? " on" : "")} x={rx} y={ex.chip.y - chh / 2} width={cw} height={chh} rx={chh / 2} />
                        <text className="chip-txt" x={rx + cw / 2} y={ex.chip.y} style={{ fontSize: fs * 0.02 }}>
                          {label}{rating ? ` · ${rating}` : ""}
                        </text>
                      </g>
                    );
                  })}
                  {/* calibration */}
                  {debug && landmarks.map((p, i) => (
                    <g key={i}>
                      <circle className="dbg-dot" cx={p.x * imgDims.w} cy={p.y * imgDims.h} r={fs * 0.0025} />
                      <text className="dbg-num" x={p.x * imgDims.w} y={p.y * imgDims.h - fs * 0.004} style={{ fontSize: fs * 0.008 }}>{i}</text>
                    </g>
                  ))}
                </svg>
              )}
            </div>
            {detecting && <p className="status">Detecting facial points…</p>}
            {detectError && <p className="status err">{detectError}</p>}
            {landmarks && !detectError && <p className="hint">Tap an area to select it</p>}
          </div>

          {activeRegion && activeEntry && (
            <div className="panel">
              <div className="panel-head">
                <h3 className="panel-title">{activeRegion.label}</h3>
                {activeEntry.split && (
                  <div className="panel-side-tabs">
                    {["right", "left"].map((s) => (
                      <button key={s} className={"side-tab" + (activeSide === s ? " active" : "")} onClick={() => setActiveSide(s)}>
                        {SIDE_LABELS[s]}
                      </button>
                    ))}
                  </div>
                )}
              </div>

              <div className="field">
                <div className="field-label">How much does it bother you?</div>
                <div className="rating">
                  {[1, 2, 3].map((n) => (
                    <button key={n} className={sideData.rating === n ? "on" : ""} onClick={() => patch({ rating: n })}>
                      {n === 1 ? "A little" : n === 2 ? "Moderate" : "A lot"}
                    </button>
                  ))}
                </div>
              </div>

              {statesForRegion(activeKey).length > 0 && (
                <div className="field">
                  <div className="field-label">What about this area concerns you? <small>(choose any)</small></div>
                  <div className="chips">
                    {statesForRegion(activeKey).map((s) => (
                      <button key={s} className={"chip" + (sideData.states.includes(s) ? " on" : "")} onClick={() => toggleState(s)}>
                        {STATE_LABELS[s]}
                      </button>
                    ))}
                  </div>
                </div>
              )}

              <div className="field">
                <div className="field-label">Anything else you'd like to add? <small>(optional)</small></div>
                <textarea placeholder="e.g. I'd like to look more refreshed" value={sideData.note} onChange={(e) => patch({ note: e.target.value })} />
              </div>

              <div className="split-row">
                {activeRegion.bilateral ? (
                  <>
                    <span>{activeEntry.split ? "Each side separately" : "Both sides together"}</span>
                    <button className="btn btn-ghost btn-sm" onClick={toggleSplit}>
                      {activeEntry.split ? "Merge sides" : "Separate sides"}
                    </button>
                  </>
                ) : <span />}
                <button className="btn btn-ghost btn-sm" onClick={() => removeRegion(activeKey)} style={{ color: "var(--danger)", borderColor: "#e0b3aa" }}>
                  Remove
                </button>
              </div>
            </div>
          )}

          <div className="summary">
            <h2>Your selections ({selectedCount})</h2>
            {selectedCount === 0 && <p className="empty">No areas selected yet.</p>}
            {Object.entries(selections).map(([key, e]) => {
              const r = regionByKey[key];
              const rows = e.split ? ["right", "left"] : ["both"];
              return rows.map((s) => {
                const d = e[s];
                if (e.split && !d.rating && !d.states.length && !d.note) return null;
                return (
                  <div className="sum-item" key={key + s}>
                    <div>
                      <div className="sum-name">{r.label}{e.split ? ` · ${SIDE_LABELS[s]}` : ""}</div>
                      <div className="sum-meta">
                        {d.states.map((x) => STATE_LABELS[x]).join(" · ")}
                        {d.note ? (d.states.length ? " — " : "") + d.note : ""}
                        {!d.states.length && !d.note ? "—" : ""}
                      </div>
                    </div>
                    <div className="sum-rating">{d.rating ? `${d.rating}/3` : ""}</div>
                  </div>
                );
              });
            })}
          </div>

          {selectedCount > 0 && (
            <div className="btn-row" style={{ marginTop: 18 }}>
              <button className="btn" onClick={exportJson}>Done</button>
              <button className="btn btn-ghost" onClick={() => console.log(JSON.stringify(intent, null, 2))}>
                Log patient_intent
              </button>
            </div>
          )}
        </>
      )}
    </div>
  );
}
